.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`external.tifffile`
================================
.. automodule:: skimage.external.tifffile

.. currentmodule:: skimage.external.tifffile
.. autosummary::

   skimage.external.tifffile.imread
   skimage.external.tifffile.imsave
   skimage.external.tifffile.imshow

   skimage.external.tifffile.TiffFile
   skimage.external.tifffile.TiffSequence
   skimage.external.tifffile.TiffWriter

imread
------

.. autofunction:: skimage.external.tifffile.imread

imsave
------

.. autofunction:: skimage.external.tifffile.imsave

imshow
------

.. autofunction:: skimage.external.tifffile.imshow


:class:`TiffFile`
-----------------


.. autoclass:: TiffFile
  :members:
  :undoc-members:
  :show-inheritance:

  .. automethod:: __init__

:class:`TiffSequence`
---------------------


.. autoclass:: TiffSequence
  :members:
  :undoc-members:
  :show-inheritance:

  .. automethod:: __init__

:class:`TiffWriter`
-------------------


.. autoclass:: TiffWriter
  :members:
  :undoc-members:
  :show-inheritance:

  .. automethod:: __init__
