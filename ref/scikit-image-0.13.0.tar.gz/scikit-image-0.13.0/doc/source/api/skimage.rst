.. AUTO-GENERATED FILE -- DO NOT EDIT!

:mod:`skimage`
==============
.. automodule:: skimage

.. currentmodule:: skimage
.. autosummary::

   skimage.dtype_limits
   skimage.img_as_bool
   skimage.img_as_float
   skimage.img_as_int
   skimage.img_as_ubyte
   skimage.img_as_uint
   skimage.test


dtype_limits
------------

.. autofunction:: skimage.dtype_limits

img_as_bool
-----------

.. autofunction:: skimage.img_as_bool

img_as_float
------------

.. autofunction:: skimage.img_as_float

img_as_int
----------

.. autofunction:: skimage.img_as_int

img_as_ubyte
------------

.. autofunction:: skimage.img_as_ubyte

img_as_uint
-----------

.. autofunction:: skimage.img_as_uint

test
----

.. autofunction:: skimage.test

