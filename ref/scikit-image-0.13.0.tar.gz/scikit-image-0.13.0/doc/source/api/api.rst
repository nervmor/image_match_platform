.. AUTO-GENERATED FILE -- DO NOT EDIT!

API Reference
=============

.. toctree::

   skimage
   skimage.color
   skimage.data
   skimage.draw
   skimage.exposure
   skimage.external.tifffile
   skimage.feature
   skimage.filters
   skimage.filters.rank
   skimage.future.graph
   skimage.graph
   skimage.io
   skimage.measure
   skimage.morphology
   skimage.novice
   skimage.restoration
   skimage.segmentation
   skimage.transform
   skimage.util
   skimage.viewer
   skimage.viewer.canvastools
   skimage.viewer.plugins
   skimage.viewer.utils
   skimage.viewer.viewers
   skimage.viewer.widgets
