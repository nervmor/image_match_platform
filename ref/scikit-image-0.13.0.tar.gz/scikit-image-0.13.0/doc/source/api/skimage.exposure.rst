.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`exposure`
=======================
.. automodule:: skimage.exposure

.. currentmodule:: skimage.exposure
.. autosummary::

   skimage.exposure.adjust_gamma
   skimage.exposure.adjust_log
   skimage.exposure.adjust_sigmoid
   skimage.exposure.cumulative_distribution
   skimage.exposure.equalize_adapthist
   skimage.exposure.equalize_hist
   skimage.exposure.histogram
   skimage.exposure.is_low_contrast
   skimage.exposure.rescale_intensity


adjust_gamma
------------

.. autofunction:: skimage.exposure.adjust_gamma

adjust_log
----------

.. autofunction:: skimage.exposure.adjust_log

adjust_sigmoid
--------------

.. autofunction:: skimage.exposure.adjust_sigmoid

cumulative_distribution
-----------------------

.. autofunction:: skimage.exposure.cumulative_distribution

equalize_adapthist
------------------

.. autofunction:: skimage.exposure.equalize_adapthist

equalize_hist
-------------

.. autofunction:: skimage.exposure.equalize_hist

histogram
---------

.. autofunction:: skimage.exposure.histogram

is_low_contrast
---------------

.. autofunction:: skimage.exposure.is_low_contrast

rescale_intensity
-----------------

.. autofunction:: skimage.exposure.rescale_intensity

