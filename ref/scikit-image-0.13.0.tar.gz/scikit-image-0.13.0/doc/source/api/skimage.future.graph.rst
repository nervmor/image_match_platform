.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`future.graph`
===========================
.. automodule:: skimage.future.graph

.. currentmodule:: skimage.future.graph
.. autosummary::

   skimage.future.graph.cut_normalized
   skimage.future.graph.cut_threshold
   skimage.future.graph.merge_hierarchical
   skimage.future.graph.ncut
   skimage.future.graph.rag_boundary
   skimage.future.graph.rag_mean_color
   skimage.future.graph.show_rag

   skimage.future.graph.RAG

cut_normalized
--------------

.. autofunction:: skimage.future.graph.cut_normalized

cut_threshold
-------------

.. autofunction:: skimage.future.graph.cut_threshold

merge_hierarchical
------------------

.. autofunction:: skimage.future.graph.merge_hierarchical

ncut
----

.. autofunction:: skimage.future.graph.ncut

rag_boundary
------------

.. autofunction:: skimage.future.graph.rag_boundary

rag_mean_color
--------------

.. autofunction:: skimage.future.graph.rag_mean_color

show_rag
--------

.. autofunction:: skimage.future.graph.show_rag


:class:`RAG`
------------


.. autoclass:: RAG
  :members:
  :undoc-members:
  :show-inheritance:

  .. automethod:: __init__
