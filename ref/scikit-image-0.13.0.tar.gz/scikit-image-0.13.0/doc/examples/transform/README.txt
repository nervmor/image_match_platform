Geometrical transformations and registration
--------------------------------------------
